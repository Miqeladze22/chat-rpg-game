
let player = {
    username: '',
    email: '',
    clan: '',
    inventory: []
};

function register() {
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (username && email && password) {
        player.username = username;
        player.email = email;
        document.getElementById("registration").classList.add("hidden");
        document.getElementById("clan-selection").classList.remove("hidden");
    } else {
        alert("Please fill in all fields.");
    }
}

function selectClan(clan) {
    player.clan = clan;
    document.getElementById("clan-selection").classList.add("hidden");
    document.getElementById("gameplay").classList.remove("hidden");
    document.getElementById("player-name").innerText = player.username;
    document.getElementById("clan-name").innerText = capitalize(clan);
    saveGame();
}

function capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
}

function enterTown() {
    showLog("You enter the town. Shops and other features coming soon!");
    saveGame();
}

function enterForest() {
    showLog("You enter the forest. Beware of monsters!");
    saveGame();
}

function viewInventory() {
    showLog("Inventory: " + (player.inventory.length ? player.inventory.join(", ") : "empty"));
    saveGame();
}

function showLog(text) {
    const log = document.getElementById("log");
    log.classList.remove("hidden");
    log.innerText = text;
}

function saveGame() {
    localStorage.setItem("chat_rpg_game", JSON.stringify(player));
}
